package com.techlabs.action;

import com.opensymphony.xwork2.ActionSupport;

public class HomeAction extends ActionSupport {

	@Override
	public String execute() throws Exception {

		return "success";
	}
}
