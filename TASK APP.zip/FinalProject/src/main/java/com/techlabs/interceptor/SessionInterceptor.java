package com.techlabs.interceptor;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class SessionInterceptor implements Interceptor {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		   System.out.println("sessionInterceptor destroy() execured");
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("sessionInterceptor init() executed");
	}

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		System.out.println("session intercept running");
	    System.out.println(invocation.getAction().getClass().getSimpleName());
	    HttpSession session = ServletActionContext.getRequest().getSession();
	    
	    System.out.println(session.getAttribute("username"));
	    System.out.println(session.getAttribute("password"));
	    if (session.getAttribute("username") != null && session.getAttribute("password") != null) {
	      System.out.println("result" + invocation.invoke());
	      return "invocation.invoke()";
	    } else {
	      return "login";
	    }
	  }
}
